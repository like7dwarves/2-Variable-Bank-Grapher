import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class LoanClient 
{
	
	
	
	public static void main(String[] args)  throws Exception
	{
		String ss = "5500";
		int d = (int)Double.parseDouble(ss);
		
		
		
		List<List<String>> records = new ArrayList<>();
		Loan loans[] = new Loan[30];
		Loan graph[][][] = new Loan[20][20][30];
		BufferedReader br = new BufferedReader(new FileReader("book.csv"));
	    String line;
	    int j=0;
	    
	    int min0=0;
	    int min1=0;
	    
	    int max0=0;
	    int max1=0;
	    
	    Loan.setData("Interest Rate", "Installments", 6, 7);
	    
	    /*
         * values[2]  = loan amount
         * values[6]  = interest rate
         * values[7]  = installments
         * values[13] = annual income
         * values[16] = loan status
         * values[20] = purpose (this is what I would put as the company)
         */
	    
	    br.readLine();
	    br.readLine();
	    while (j<30&&(line = br.readLine()) != null) {
	        String[] values = line.split("\",\"");
	        records.add(Arrays.asList(values));
	        if(values[20].toLowerCase().contains("consolidation"))
	        {
		        loans[j] = new Loan(new int[]{Loan.parseTypeToInt(Loan.location[0], values[Loan.location[0]]),Loan.parseTypeToInt(Loan.location[1], values[Loan.location[1]])},values[16], values[20]);
		        if(j==0)
		        {
		        	min0 = loans[0].values[0];
		        	max0 = loans[0].values[0];
		        	min1 = loans[0].values[1];
		        	max1 = loans[0].values[1];
		        }
		        else
		        {
		        	min0 = Math.min(min0, loans[j].values[0]);
		        	max0 = Math.max(max0, loans[j].values[0]);
		        	min1 = Math.min(min1, loans[j].values[1]);
		        	max1 = Math.max(max1, loans[j].values[1]);
		        }
		        System.out.println(loans[j]);
		        j++;
	        }
	    }
	    //x axis;
	    double interval0 = (double)(max0-min0)/(graph[0].length-1);
	    //y axis;
	    double interval1 = (double)(max1-min1)/(graph.length-1);
	    for(int i=0; i<loans.length; i++)
	    {
	    	int xLoc = (int)((loans[i].values[0]-min0)/interval0);
	    	int yLoc = (int)((loans[i].values[1]-min1)/interval1);

	    	graph[yLoc][xLoc]=addLoanToArray(loans[i], graph[yLoc][xLoc]);
	    	System.out.println(xLoc+", "+yLoc);
	    }
	    
	    FileWriter fileWriter = new FileWriter("output.txt");
	    PrintWriter printWriter = new PrintWriter(fileWriter);
	    
	    for(int y=0; y<graph.length; y++)
	    {
	    	for(int x=0; x<graph[0].length;x++)
	    	{
	    		int totalPaidOff=0;
	    		int total = 0;
	    		for(int z=0; z<graph[0][0].length; z++)
	    		{
	    			System.out.print(graph[y][x][z]==null);
	    			if(graph[y][x][z]!=null)
	    			{
	    				if(graph[y][x][z].defaulted==1)
	    					totalPaidOff++;
	    				total++;
	    			}
	    		}
	    		System.out.println();
	    		printWriter.print("\""+totalPaidOff+" / "+total+"\"");
	    		if(x!=graph[0].length-1)
	    			printWriter.print(",");
	    	}
	    	printWriter.println();
	    	System.out.println();
	    }
	    printWriter.close();
	}
	
	public static Loan[] addLoanToArray(Loan l, Loan[] a)
	{
		Loan[] b = new Loan[a.length+1];
		boolean storedL = false;
		for(int i=0; i<a.length; i++)
		{
			if(!storedL&&a[i]==null)
			{
				b[i] = new Loan(new int[]{l.values[0],l.values[1]}, l.defaulted, l.corporation);
				storedL = true;
			}
			else if(a[i]!=null)
			{
				b[i] = new Loan(new int[]{a[i].values[0],a[i].values[1]}, a[i].defaulted, a[i].corporation);
			}
		}
		b[a.length]=null;
		a = b;
		return a;
	}
}
