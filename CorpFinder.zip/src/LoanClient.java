import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class LoanClient 
{
	
	
	
	public static void main(String[] args)  throws Exception
	{
		String ss = "5500";
		int d = (int)Double.parseDouble(ss);
		
		
		
		List<List<String>> records = new ArrayList<>();
		Loan loans[] = new Loan[30];
		Loan graph[][][] = new Loan[20][20][30];
		BufferedReader br = new BufferedReader(new FileReader("book.csv"));
	    String line;
	    int j=0;
	    
	    int min0=0;
	    int min1=0;
	    
	    int max0=0;
	    int max1=0;
	    
	    Loan.setData("Interest Rate", "Installments", 6, 7);
	    
	    /*
         * values[2]  = loan amount
         * values[6]  = interest rate
         * values[7]  = installments
         * values[13] = annual income
         * values[16] = loan status
         * values[20] = purpose (this is what I would put as the company)
         */
	    
	    br.readLine();
	    br.readLine();
	    while (j<30&&(line = br.readLine()) != null) {
	        String[] values = line.split("\",\"");
	        records.add(Arrays.asList(values));
	        loans[j] = new Loan(new int[]{Loan.parseTypeToInt(Loan.location[0], values[Loan.location[0]]),Loan.parseTypeToInt(Loan.location[1], values[Loan.location[1]])},values[16], values[20]);
	        
	        if(j==0)
	        {
	        	min0 = loans[0].values[0];
	        	max0 = loans[0].values[0];
	        	min1 = loans[0].values[1];
	        	max1 = loans[0].values[1];
	        }
	        else
	        {
	        	min0 = Math.min(min0, loans[j].values[0]);
	        	max0 = Math.max(max0, loans[j].values[0]);
	        	min1 = Math.min(min1, loans[j].values[1]);
	        	max1 = Math.max(max1, loans[j].values[1]);
	        }
	        System.out.println(loans[j]);
	        j++;
	    }
	    int x = 0;
	    //first deals with the x axis;
	    for(int i=0; i<loans.length; i++)
	    {
	    	
	    }
	}
	
	public void addLoanToArray(Loan l, Loan[] a)
	{
		Loan[] b = new Loan[a.length+1];
		for(int i=0; i<a.length; i++)
		{
			b[i] = l.toNewLoan();
		}
	}
}
