

public class Loan
{
	String corporation;
	
	static String[] quantity; //the name of the integers we are measuring
	static int[] location; //the (probably 2) integers we are actually measuring
	
	int[] values;
	
	int defaulted; //1 = paid off loan; 0 = still paying; -1 = defaulted
	
	public Loan(int[] vals, String val16, String val20) 
	{
		values = vals;
		defaulted = parseTypeToInt(16,val16);
		corporation = val20;
	}
	
	public Loan(int[] vals, int default0, String corp) 
	{
		values = vals;
		defaulted = default0;
		corporation = corp;
	}
	
	public int getDefaults(String val16)
	{
		if(val16.equals("Fully Paid"))
		{
			return 1;
		}
		else if(val16.equals("Charged Off"))
		{
			return -1;
		}
		return 0;
	}
	
	public static void setData(String q1, String q2, int i1, int i2)
	{
		quantity = new String[2];
		quantity[0] = q1;
		quantity[1] = q2;
		location = new int[2];
		location[0] = i1;
		location[1] = i2;
	}
	
	public Loan toNewLoan()
	{
		return new Loan(new int[]{values[0],values[1]}, defaulted, corporation);
	}
	
	/*
     * values[2]  = loan amount
     * values[6]  = interest rate
     * values[7]  = installments
     * values[13] = annual income
     * values[16] = loan status
     * values[20] = purpose (this is what I would put as the company)
     * values[23] = state
     */
	
	public static int parseTypeToInt(int loc, String val)
	{
		if(loc==2)
			return Integer.parseInt(val);
		else if(loc==6)
			return (int)Double.parseDouble(val.substring(0, val.length()-1));
		else if(loc==7)
			return (int)Double.parseDouble(val);
		else if(loc==13)
			return Integer.parseInt(val);
		else if(loc==16)
		{
			if(val.equals("Fully Paid"))
				return 1;
			else if(val.equals("Charged Off"))
				return -1;
			return 0;
		}
		return 0;
	}

	public String toString()
	{
		String returned=corporation.toString()+", "+defaulted+" (";
		for(int i=0; i<values.length-1; i++)
		{
			returned = returned+quantity[i]+" = "+values[i]+", ";
		}
		if(values.length!=0)
			returned = returned + quantity[values.length-1]+" = "+values[values.length-1]+")";
		return returned;
	}
}
